// Example 1.1 A simple C++ program

#include <iostream>

using namespace std;

int main()
{
	cout << "The best place to start is at the beginning";
	return 0;
}