// Program 1.2 Using escape sequences
#include <iostream>
using namespace std;

int main()
{
  cout << "\n\"Least said\n\t\tsoonest mended.\"\n\a";
  return 0;
}
