// Program 10.2 Using a namespace   Data10_2.cpp
#include <string>

namespace data
{
  extern const double pi = 3.14159265;
  extern const std::string days[] = {
                                      "Sunday",   "Monday", "Tuesday", "Wednesday",
                                      "Thursday", "Friday", "Saturday"
                                    };
}
