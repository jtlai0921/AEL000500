// functions.h
#if !defined FUNCTIONS_H
#define FUNCTIONS_H
namespace fun
{
  // Function prototypes
  int sum(int, int);                // Sum arguments
  int product(int, int);            // Product of arguments
  int difference(int, int);         // Difference between arguments
}
#endif


