// Box.cpp
#include "box.h"

// Constructor
Box::Box(double lv, double bv, double hv) : length(lv), breadth(bv), height(hv)
{}
