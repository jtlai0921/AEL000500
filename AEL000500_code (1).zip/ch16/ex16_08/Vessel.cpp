// Vessel.cpp
#include <iostream>
#include "Vessel.h"
using namespace std;

Vessel::~Vessel()
{
  cout << "Vessel destructor" << endl;
}