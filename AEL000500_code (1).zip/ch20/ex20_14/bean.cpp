// File "Bean.cpp"
#include "bean.h"
   
Account Bean::log;
